arquivo=open("exemplo.txt", "rt")

texto=arquivo.read()[:-1]
print(f"read:\n{texto}")

arquivo.seek(0)

linha=arquivo.readline().rstrip()
print(f"linha 1: {linha}")

arquivo.seek(0)

linhas=arquivo.readlines()
print(linhas)

arquivo.seek(0)

lista=[]
for linha in arquivo:
 lista.append(linha.rstrip())

print(lista)



arquivo.close()
