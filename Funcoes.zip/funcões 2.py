a=20



def funcao1():
  a=20
  print("função 1:", a)



def funcao2():
  print("função 2:", a)


def funcao3():
  global a
  print("Função 3.1:", a)
  a=20
  print("Função 3.2", a)



funcao1()
funcao2()
funcao3()
