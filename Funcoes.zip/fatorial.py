def fatorial(numero):
  fatorial=1


for i in range(numero, 1 , -1):
  fatorial *= i

return fatorial

while True:
  numero=float(input("Digite um numero: "))
  if numero>=0:
    break
  else:
    print("Valor invalido!")