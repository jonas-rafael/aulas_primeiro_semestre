def ma(valores):
  soma = 0

  for valor in valores:
    soma += valor

  return soma / len(valores)

def ler_nota(mensagem):
  while True:
    nota= float(input(mensagem))

    if 0 <= nota <= 10:
      break
    else:
      print("Nota invalida!")
    
  return nota 


if __name__ == "__main__":
  nota1= ler_nota("Digite a primeira nota: ")
  nota2= ler_nota("Digite a segunda nota: ")
  
  media = ma(nota1, nota2)
  print(f"media do aluno é {media:.1f}!")
  
  if media >= 7:
    print("aluno aprovado!")
  else:
    print(" aluno reprovado!")