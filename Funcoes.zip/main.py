import media
#-------------------------------------------------
n1= media.ler_nota("Digite a nota 1: ")
n2= media.ler_nota("Digite a nota 2: ")
n3=media.ler_nota("Digite a nota 3: ")
n4=media.ler_nota("Digite a nota 4: ")

print("Media:", media.ma(n1+n2+n3+n4)/4)
