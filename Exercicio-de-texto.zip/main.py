def carregar_arquivo(nome_arquivo):
  lista=[]
  arquivo=open(nome_arquivo, "r")

#para retirada do cabeçalho, ja que quando lê a linha ela não volta sem o seek.
  arquivo.readline()

  for linha in arquivo:
    campos=(linha.strip().split(";"))
    campos[1]= campos[1].upper()
    lista.append(campos)
  arquivo.close()
  return lista


aluno=carregar_arquivo("relatorio")

 




def imprimir_aluno(aluno):
  print("Matricula: ", aluno[0])
  print("Nome: ", aluno[1])
  print("campus: ", aluno[2])
  print("Código do aluno: ",aluno [3])
  print("E-mail escolar: ",aluno[4])
  print("Município: ", aluno[5])
  print("Nível escolar: ",aluno[6])
  print("Situação escolar: ", aluno[7])
  print("Escola de origem: ",aluno[8])
alunos = carregar_arquivo("Relatorio")





while True:
  print("0 - Para sair do programa ")
  print("1 - Lista de todos os alunos ")
  print("2 - Busca exta pro matricula ")
  print("3 - Busca aproximada por nome ")
  print("4- Contar alçunos por escolas de origem ")
  print("5 - Conta situação dos alunos do municipio")
  opção=int(input(">> "))


  if opção ==0:
    print("Finalizando o programa...")
    break
  elif opção ==1:
    for a in alunos:
      print(" # # #")
      imprimir_aluno(a)
  elif opção ==2:
    matricula=input("Insira a matricula que deseja buscar: ") 
    encontrado=False  

    for a in alunos:
      if matricula == a[0]:
        encontrado = True
        imprimir_aluno(a)
        break
    if not encontrado:
      print ("Matricula não encontrada, tente novamente!")


