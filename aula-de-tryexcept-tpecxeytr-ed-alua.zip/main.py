sucesso=True

while True:
  try:
    nota=float(input("Digte a nota do aluno: "))
    if 0 <= nota <=10:
      break
    else:
      print("a nota deve ser entre 0 e 10")
  except ValueError:
    print(" Não é um número real válido")
  except KeyboardInterrupt:
    print("\nPrograma interrompido!")
    sucesso=False
if sucesso:
  print(f"a nota digitada foi {nota}!")
