arquivo= open("contato.csv", "a")

nome=input("Digite o nome do contato: ")
telefone=input("Insira o o número do telefone: ")
nasc=input("Insira a data de nascimento do contato: ")
arquivo.write(30*"-")
arquivo.write(f"\n Nome:{nome}.\n Telefone:{telefone}.\n Nascimento: {nasc}.\n")
arquivo.write(30*"-")

arquivo.close()
